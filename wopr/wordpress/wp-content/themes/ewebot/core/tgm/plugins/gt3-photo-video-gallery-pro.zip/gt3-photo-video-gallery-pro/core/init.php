<?php

namespace GT3\PhotoVideoGalleryPro;

defined('ABSPATH') OR exit;

require_once __DIR__.'/autoload.php';

require_once __DIR__.'/cpt/gallery/init.php';


